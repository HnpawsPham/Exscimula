const container = document.getElementById("container");
const emailsContainer = document.getElementById("emails");
const pagesContainer = document.getElementById("pages");

let userNotes = JSON.parse(localStorage.getItem("userNotes")) ||
{
    emails: {},
    pages : {}
}

function createNewPost(){
    let post = document.createElement("div");
    post.classList.add("post");

    let head = document.createElement("div");
    head.classList.add("head");

    let heading = document.createElement("h2");
    heading.innerHTML = prompt("Tiêu đề?");
    head.appendChild(heading);

    let date = document.createElement("i");
    let milisec = new Date().getTime();
    let currentDate = new Date(milisec);
    date.innerHTML = currentDate.toLocaleString();
    head.appendChild(date);
    post.appendChild(head);

    let contentContainer = document.createElement("div");
    contentContainer.classList.add("content");

    let text = document.createElement("p");
    text.innerHTML = prompt("Ghi gì?");
    contentContainer.appendChild(text);
    post.appendChild(contentContainer);

    container.appendChild(post);
}

const selectForm = document.getElementById("select");
function showOptions(){
    selectForm.style.display = "flex"
    let options = document.getElementsByClassName("option");

    selectForm.addEventListener("submit",function(e){
        e.preventDefault();
        selectForm.style.display = "none";

        if(options[0].checked){
            window.open("../pages/email-form.html");
        }
        else{
            window.open("../pages/page-form.html");
        }
    })
}

