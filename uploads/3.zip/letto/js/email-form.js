const submitBtn = document.getElementById("submit-btn");
const receiverAddress = document.getElementById("receiver-address");
const receiverName = document.getElementById("receiver-name");
const contentArea = document.getElementById("content");

const addEmojiBtn = document.getElementById("add-emoji-btn");
const emojiTab = document.getElementById("emoji-tab");
const emojisContainer = document.getElementById("container")

let info = [];


submitBtn.addEventListener("click", function () {
    alert("Sent successfully!");
    
    info.push({
        name: receiverName.value,
        address: receiverAddress.value,
        content: contentArea.value
    })

    console.log(info)
})


let emojiGroups = [
    "smileys_emotion",
    "people_body",
    "component",
    "animals_nature",
    "food_drink",
    "travel_places",
    "activities",
    "objects",
    "symbols",
    "flags"
];

let cursor = 0;

function changeCursor(value){
    if(cursor + value >=0){
        cursor+=value;
    }
    else{
        cursor = emojiGroups.length - 1;
    }

    loadEmojis(emojiGroups[cursor]);
}

function loadEmojis(group){
    emojisContainer.replaceChildren();

    $.ajax({
        method: 'GET',
        url: "https://api.api-ninjas.com/v1/emoji?group=" + group,
        headers: { 'X-Api-Key': '/2RA1o7/9ISpiShw/svjrQ==sIqIi0ZNAAHHMkXo' },
        contentType: 'application/json',
        success: function (res) {
            // load emojis 
            for(let elm of res){
                let span = document.createElement("span");
                span.innerHTML = elm.character;

                span.addEventListener("click",function(){
                    contentArea.value += span.innerHTML;
                })

                emojisContainer.appendChild(span);
            }
        },
        error: function ajaxError(jqXHR) {
            console.error('Error: ', jqXHR.responseText);
        }
    });
}

addEmojiBtn.addEventListener("click", function(){
    emojiTab.style.display = "block";
    loadEmojis(emojiGroups[cursor])
})

contentArea.addEventListener("click",function(){
    emojiTab.style.display = "none";
})