const clientId = '29b56bdda4f74886986e528152f54cf5';
const clientSecret = 'eb4daa84041649a89316ffd681cf2401';

async function getToken(){
    fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: {
            'Content-Type' : 'application/x-www-form-urlencoded', 
            'Authorization' : 'Basic ' + btoa( clientId + ':' + clientSecret)
        },
        body: 'grant_type=client_credentials'
    })
    .then(function (res){
        return res.json();
    })
    .then(function (data){
        try {
            getPlaylist(data.access_token)
        }
        catch { }
    })
}

async function getPlaylist(token){
    let id = prompt("ID playlist spotify?").slice(34);

    const res = await fetch("https://api.spotify.com/v1/playlists/" + id, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
    const data = await res.json()
    console.log(data)
    return data;
}

const data=getPlaylist;

const spotifyEmbed = document.getElementById("spotify-embed");
const musicBtn = document.getElementById("music-btn");
const playlist_id = document.getElementById("playlist-id");
const suggestedPlaylist = document.getElementById("suggested-playlist");


musicBtn.addEventListener("click",function(){
    if(playlist_id.value != "" && !playlist_id.value.includes(' ')){
        let ID = playlist_id.value.substring(34,56);
        spotifyEmbed.src = `https://open.spotify.com/embed/playlist/${ID}?utm_source=generator&theme=0`
    }
    else{
        alert("Please enter a correct spotify playlist ID!");
    }

    playlist_id.value = "";
})

suggestedPlaylist.addEventListener("click",function(){
    spotifyEmbed.src = `https://open.spotify.com/embed/playlist/4SyqPrpD1yGm33Ychi3ac0?utm_source=generator&theme=0`
    alert("Hope you enjoy!");
})




