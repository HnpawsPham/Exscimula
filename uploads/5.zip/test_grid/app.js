let data = ['assets/131682-car-night-dark-street.jpg',
            'assets/1319739.jpeg',
            'assets/164284.jpg',
            'assets/221-2211142_dark-forest-wallpaper.jpg',
            'assets/6334f086850f820995ec216f88b8e43e.jpg',
            'assets/anRhCU.jpg',
            'assets/cozy-warm-aesthetic-evening-atmosphere-with-open-book-plaid-soft-focus_370028-5475.avif',
            'assets/game-forza-horizon-4-fh4-1.jpg',
            'assets/guitar.jpg', 'assets/image-2-30.webp',
            'assets/jaoiw.jpg', 'assets/jc578z5khxw41.jpg',
            'assets/lofi%20girl.jpg', 'assets/mTxNxsN.jpg',
            'assets/nbzOYvkt34N-Wd51ACAnPV5_hGA6ZHo8gGJ3-CjqcMI.jpg',
            'assets/porsche-gt3-911-gt-rear-dm.jpg', 'assets/TLOU%205.jpg',
            'assets/TLOU.jpg'];



const grid = document.getElementById("grid");

for (let elm of data) {
    let img = document.createElement("img");
    img.src = elm;

    let ratio = Math.max(img.height,img.width) / Math.min(img.height,img.width);

    img.style.width = 200 * ratio + "px";
    img.style.height = "200px";

    img.onclick = function(){
        window.open(elm)
    }
   
    grid.appendChild(img);
}