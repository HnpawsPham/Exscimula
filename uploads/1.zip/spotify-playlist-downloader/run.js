const source = document.getElementById("source")
const playlistName = document.getElementById("name")
const image = document.getElementById("image")
const downloadBtn = document.getElementById("download-btn")

const clientId = '374f403eee7b42c2af9dc3b0d8f32dfa';
const clientSecret = '27926e81e11b40c5810bc95029d1f510';

function getToken() {
    fetch("https://accounts.spotify.com/api/token", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Basic ' + btoa(clientId + ':' + clientSecret)
        },
        body: 'grant_type=client_credentials'
    })
        .then(function (res) {
            return res.json()
        })
        .then(function (data) {
            try {
                console.log(data.access_token)
                getPlaylist(data.access_token)
            }
            catch { }
        })
}
async function getPlaylist(token) {
    let playlist_id = source.value.slice(34)
    console.log(playlist_id)
    try {
        const response = await fetch("https://api.spotify.com/v1/playlists/" + playlist_id, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        const data = await response.json()
        console.log(data)
        setInfo(data)
    }
    catch (err) { }
}
source.addEventListener("change", function (e) {
    if (source.value != "") {
        getToken()
    }
})
downloadBtn.addEventListener("click", function () {
    getToken()
})
// lấy cái thông tin của playlist
function setInfo(data) {
    image.src = data.images[0].url
    playlistName.innerHTML = data.name
}

function mergeVideos() {
    const ffmpeg = require('ffmpeg-static');
    const fs = require('fs');
    const { execFileSync } = require('child_process');

    const outputVideoFile = 'output.mp4';

    // These are the paths to the two input videos you want to merge 
    const inputVideo1 = 'video1.mp4';
    const inputVideo2 = 'video2.mp4';

    // Use the ffmpeg library to merge the two input videos 
    execFileSync(ffmpeg, ['-i', inputVideo1, '-i', inputVideo2, '-filter_complex', '[0:v] [0:a] [1:v] [1:a] concat=n=2:v=1:a=1 [v] [a]', '-map', '[v]', '-map', '[a]', outputVideoFile], { stdio: 'inherit' });

    console.log('Video merge complete!');
}
function converter(){
    fetch("https://api.spotify.com/v1/audio-analysis/2takcwOaAZWiXQijPHIx7B", {
        method: 'GET',
        headers: {
            'Authorization': `Bearer BQCEkTucFs74QRrktz0pVz2puud3eVj-NW4E_PUMbtE1PVMS2KnBP5Afxea4jKlIvOJWQ0P4qpO78KHYeHdyJ5TP6g0C4vBbupiLiQuDLJ22W9mjogk`
        }
    })
    .then(function(res){
        return res.json()
    })
    .then(function(data){
        console.log(data)
    })
}
converter()